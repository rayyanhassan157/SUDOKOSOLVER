import java.util.HashSet;
import java.util.Scanner;


class SudokuSolver {

    private static final int SIZE = 9;
    private static final int BOX = 3;


    private HashSet<Integer>[] rows = new HashSet[SIZE];
    private HashSet<Integer>[] cols = new HashSet[SIZE];
    private HashSet<Integer>[] boxes = new HashSet[SIZE];

    private int[][] board;
    private long backtrackCount = 0; // counts failed placements (used for difficulty rating)

    public SudokuSolver(int[][] board) {
        this.board = board;
        for (int i = 0; i < SIZE; i++) {
            rows[i] = new HashSet<>();
            cols[i] = new HashSet<>();
            boxes[i] = new HashSet<>();
        }
        initializeSets();
    }


    private void initializeSets() {
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                int val = board[r][c];
                if (val != 0) {
                    rows[r].add(val);
                    cols[c].add(val);
                    boxes[boxIndex(r, c)].add(val);
                }
            }
        }
    }

    private int boxIndex(int r, int c) {
        return (r / BOX) * BOX + (c / BOX);
    }


    private boolean isValid(int r, int c, int num) {
        return !rows[r].contains(num) &&
                !cols[c].contains(num) &&
                !boxes[boxIndex(r, c)].contains(num);
    }

    private void place(int r, int c, int num) {
        board[r][c] = num;
        rows[r].add(num);
        cols[c].add(num);
        boxes[boxIndex(r, c)].add(num);
    }

    private void remove(int r, int c, int num) {
        board[r][c] = 0;
        rows[r].remove(num);
        cols[c].remove(num);
        boxes[boxIndex(r, c)].remove(num);
    }


    public boolean solve() {
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                if (board[r][c] == 0) {
                    for (int num = 1; num <= 9; num++) {
                        if (isValid(r, c, num)) {
                            place(r, c, num);
                            if (solve()) {
                                return true;
                            }
                            remove(r, c, num);          // backtrack
                            backtrackCount++;            // count failed attempt
                        }
                    }
                    return false; // no number fits -> trigger backtracking
                }
            }
        }
        return true; // all cells filled
    }

    public long getBacktrackCount() {
        return backtrackCount;
    }


    public String getDifficultyRating() {
        if (backtrackCount == 0) {
            return "Easy (no backtracking required)";
        } else if (backtrackCount < 50) {
            return "Easy";
        } else if (backtrackCount < 1000) {
            return "Medium";
        } else if (backtrackCount < 10000) {
            return "Hard";
        } else {
            return "Expert";
        }
    }

    public void printBoard() {
        for (int r = 0; r < SIZE; r++) {
            if (r % BOX == 0 && r != 0) {
                System.out.println("------+-------+------");
            }
            for (int c = 0; c < SIZE; c++) {
                if (c % BOX == 0 && c != 0) {
                    System.out.print("| ");
                }
                System.out.print(board[r][c] == 0 ? ". " : board[r][c] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        // Sample Sudoku puzzle (0 represents empty cells)
        int[][] puzzle = {
                {5, 3, 0, 0, 7, 0, 0, 0, 0},
                {6, 0, 0, 1, 9, 5, 0, 0, 0},
                {0, 9, 8, 0, 0, 0, 0, 6, 0},
                {8, 0, 0, 0, 6, 0, 0, 0, 3},
                {4, 0, 0, 8, 0, 3, 0, 0, 1},
                {7, 0, 0, 0, 2, 0, 0, 0, 6},
                {0, 6, 0, 0, 0, 0, 2, 8, 0},
                {0, 0, 0, 4, 1, 9, 0, 0, 5},
                {0, 0, 0, 0, 8, 0, 0, 7, 9}
        };

        SudokuSolver solver = new SudokuSolver(puzzle);

        System.out.println("Initial Puzzle:");
        solver.printBoard();

        long startTime = System.nanoTime();
        boolean solved = solver.solve();
        long endTime = System.nanoTime();

        System.out.println("\nSolved Puzzle:");
        if (solved) {
            solver.printBoard();
        } else {
            System.out.println("No solution exists for the given puzzle.");
        }

        System.out.println("\n--- Performance Analysis ---");
        System.out.println("Backtrack Count : " + solver.getBacktrackCount());
        System.out.println("Difficulty      : " + solver.getDifficultyRating());
        System.out.println("Time Taken      : " + (endTime - startTime) / 1_000_000.0 + " ms");
    }
}